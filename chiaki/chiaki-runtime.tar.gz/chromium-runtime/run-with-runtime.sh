#!/bin/sh
set -e
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
export LD_LIBRARY_PATH="$HERE/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export SSL_CERT_FILE="$HERE/certs/ca-certificates.crt"
export SSL_CERT_DIR="$HERE/certs"
# Immutable images are often nosuid: skip FUSE probe to silence warning
export APPIMAGE_EXTRACT_AND_RUN=1
# Tame keyring/DBus noise on appliance images
EXTRA_FLAGS="--no-sandbox --password-store=basic"
exec "$@" $EXTRA_FLAGS
