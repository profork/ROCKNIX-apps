This bundle provides the NSS/NSPR + softoken/freebl + CA certs Chromium/Electron need.

To run an AppImage with this runtime (Rocknix/Batocera style systems):
  APPIMAGE_EXTRACT_AND_RUN=1 \
  LD_LIBRARY_PATH="$PWD/chromium-runtime/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
  SSL_CERT_FILE="$PWD/chromium-runtime/certs/ca-certificates.crt" \
  SSL_CERT_DIR="$PWD/chromium-runtime/certs" \
  ./Your.AppImage --no-sandbox --password-store=basic

You can also extract the AppImage and run the inner binary with the same env.
